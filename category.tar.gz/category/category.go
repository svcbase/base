package category

import (
	"base"
	"database/sql"
	"district"
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
	"web"

	"github.com/gorilla/sessions"
)

const (
	PAGE_ROWS    = 20
	BLANK_CUTSET = "\r\n\t "
	NO_ROWS      = "no rows in result set"
	CODE_RPAD    = "/0/00/00,0/0000,00"
)

var errorLog, accessLog, visitLog *log.Logger
var cookieStore *sessions.CookieStore

func SetParam(elog, alog, vlog *log.Logger, cs *sessions.CookieStore) {
	errorLog = elog
	accessLog = alog
	visitLog = vlog
	cookieStore = cs
	return
}

func CategoryHandler(w http.ResponseWriter, r *http.Request) {
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		db := base.DB()
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		if db != nil {
			nrows := 0
			asql := "select count(*) ct from category"
			row := db.QueryRow(asql)
			if row != nil {
				err := row.Scan(&nrows)
				if err != nil {
					errorLog.Println(err)
				}
			}
			locals["rows"] = nrows
			type categoryT struct {
				Bg          string
				Category_id string
				Name        string
				Time_added  string
				Status      string
			}
			ipage, pages := base.Paging(nrows, r.FormValue("p"))
			locals["showflip"] = (pages > 1)

			categories := []categoryT{}
			asql = "select category_id,name," + base.SQL_dateformatYmd("time_added") + ",status from category"
			asql += " order by time_added desc limit " + fmt.Sprintf("%d", (ipage-1)*base.PAGE_ROWS) + "," + fmt.Sprintf("%d", ipage*base.PAGE_ROWS)
			rows, e := db.Query(asql)
			if e == nil {
				n := 0
				for rows.Next() {
					var category_id, time_added, status string
					var name sql.NullString
					e = rows.Scan(&category_id, &name, &time_added, &status)
					if e == nil {
						var c categoryT
						n++
						if n%2 == 0 {
							c.Bg = "F3F3F3"
						} else {
							c.Bg = "FFFFFF"
						}
						c.Category_id = category_id
						c.Name = name.String
						c.Time_added = time_added
						c.Status = status
						categories = append(categories, c)
					} else {
						errorLog.Println(e)
					}
				}
				rows.Close()
			} else {
				errorLog.Println(asql, e)
			}
			locals["category"] = categories
			locals["pageflip"] = template.HTML(web.PageFlip("category", "First/Previous/Next/Last", nrows, PAGE_ROWS, ipage))
		}
		web.AdminHtml(w, r, "category", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func AcategoryHandler(w http.ResponseWriter, r *http.Request) {
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		r.ParseForm()
		categoryid := strings.Trim(r.FormValue("id"), BLANK_CUTSET)
		db := base.DB()
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		padformats := ""
		if db != nil {
			if r.Method == "POST" {
				categoryid = r.FormValue("categoryid")
				token := r.FormValue("token")
				padformats = r.FormValue("pad_formats")
				categoryname := strings.Trim(r.FormValue("categoryname"), BLANK_CUTSET)
				if len(categoryname) == 0 {
					locals["echo"] = "NAME can not be empty!"
					locals["categoryid"] = categoryid
					locals["token"] = token
				} else {
					if len(categoryid) == 0 && len(token) > 0 {
						asql := "select category_id from category where token=?"
						row := db.QueryRow(asql, token)
						if row != nil {
							var c_id string
							e := row.Scan(&c_id)
							if e == nil && len(c_id) > 0 {
								categoryid = c_id
							}
						}
					}
					if len(categoryid) > 0 {
						asql := "update category set name=?,pad_formats=? where category_id=?"
						_, e := db.Exec(asql, categoryname, padformats, categoryid)
						if e != nil {
							errorLog.Println(asql, categoryname, padformats, categoryid, e.Error())
						}
					} else {
						asql := "insert into category(name,pad_formats,time_added,token) values(?,?," + base.SQL_now() + ",?)"
						rslt, e := db.Exec(asql, categoryname, padformats, token)
						if e == nil {
							id, err := rslt.LastInsertId()
							if err == nil {
								categoryid = strconv.FormatInt(id, 10)
							}
						} else {
							errorLog.Println(asql, categoryname, e.Error())
						}
					}
					http.Redirect(w, r, "/categoryview?id="+categoryid, http.StatusFound)
				}
			} else {
				if base.IsDigital(categoryid) {
					asql := "select name,pad_formats from category where category_id=?"
					row := db.QueryRow(asql, categoryid)
					if row != nil {
						var name, pf sql.NullString
						e := row.Scan(&name, &pf)
						if e == nil {
							locals["categoryid"] = categoryid
							locals["categoryname"] = name.String
							padformats = pf.String
						}
					}
				} else {
					locals["token"] = time.Now().UnixNano()
				}
			}
		}
		type padT struct {
			PAD      string
			Selected bool
		}
		pads := []padT{}
		crs := strings.Split(CODE_RPAD, "/")
		for _, cr := range crs {
			pads = append(pads, padT{cr, padformats == cr})
		}
		locals["pad_formats"] = pads
		web.AdminHtml(w, r, "acategory", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func CategoryremoveHandler(w http.ResponseWriter, r *http.Request) {
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		db := base.DB()
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		if db != nil {
			categoryid := "0"
			r.ParseForm()
			if r.Method == "POST" {
				categoryid = r.FormValue("categoryid")
				if base.IsDigital(categoryid) {
					if len(r.FormValue("remove")) > 0 {
						asql := "delete from category where category_id=?"
						db.Exec(asql, categoryid)
						asql = "delete from category_item where category_id=?"
						db.Exec(asql, categoryid)
						asql = "delete from category_description where category_id=?"
						db.Exec(asql, categoryid)

						http.Redirect(w, r, "/category", http.StatusFound)
					} else {
						http.Redirect(w, r, "/categoryview?id="+categoryid, http.StatusFound)
					}
				}
				return
			} else {
				categoryid = strings.Trim(r.FormValue("id"), BLANK_CUTSET)
			}

			if base.IsDigital(categoryid) {
				asql := "select name," + base.SQL_dateformatYmd("time_added") + ",status from category where category_id=?"
				row := db.QueryRow(asql, categoryid)
				if row != nil {
					var name sql.NullString
					var timeadded, status string
					e := row.Scan(&name, &timeadded, &status)
					if e == nil {
						locals["categoryid"] = categoryid
						locals["categoryname"] = name.String
						locals["timeadded"] = timeadded
						locals["status"] = status
					}
				}
			}
		}
		web.AdminHtml(w, r, "categoryremove", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func CategoryviewHandler(w http.ResponseWriter, r *http.Request) {
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		db := base.DB()
		r.ParseForm()
		categoryid := strings.Trim(r.FormValue("id"), BLANK_CUTSET)
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		if base.IsDigital(categoryid) && db != nil {
			asql := "select name,pad_formats," + base.SQL_dateformatYmd("time_added") + ",status,item_count from category where category_id=?"
			row := db.QueryRow(asql, categoryid)
			if row != nil {
				var name, pf sql.NullString
				var timeadded, status string
				var item_count int
				e := row.Scan(&name, &pf, &timeadded, &status, &item_count)
				if e == nil {
					locals["categoryid"] = categoryid
					locals["categoryname"] = name.String
					locals["pad_formats"] = pf.String
					locals["timeadded"] = timeadded
					locals["status"] = status
					locals["item_count"] = item_count
				}
			}
		}

		web.AdminHtml(w, r, "categoryview", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func saveItem(categoryid, languageid, code, name, description string) {
	if base.DB() != nil {
		var cii int64 = 0
		asql := "select category_item_id from category_item where category_id=? and identifier=?"
		row := base.DB().QueryRow(asql, categoryid, code)
		if row != nil {
			e := row.Scan(&cii)
			if e != nil && !strings.Contains(e.Error(), NO_ROWS) {
				errorLog.Println(asql, categoryid, code, e.Error())
			}
		}
		if cii > 0 {
			asql = "update category_item set identifier=? where category_item_id=?"
			_, e := base.DB().Exec(asql, code, cii)
			if e == nil {
				n := 0
				asql = "select count(*) ct from category_description where category_item_id=? and language_id=?"
				row = base.DB().QueryRow(asql, cii, languageid)
				if row != nil {
					row.Scan(&n)
				}
				if n == 0 {
					asql = "insert into category_description(category_item_id,language_id,category_id,item_name,item_description)"
					asql += " values(?,?,?,?,?)"
					_, e = base.DB().Exec(asql, cii, languageid, categoryid, name, description)
					if e != nil {
						errorLog.Println(asql, cii, languageid, categoryid, name, description, e.Error())
					}
				} else {
					asql = "update category_description set item_name=?,item_description=? where category_item_id=? and language_id=?"
					_, e = base.DB().Exec(asql, name, description, cii, languageid)
					if e != nil {
						errorLog.Println(asql, name, description, cii, languageid, e.Error())
					}
				}
			} else {
				errorLog.Println(asql, code, cii)
			}
		} else {
			asql = "insert into category_item(category_id,identifier,time_added) values(?,?," + base.SQL_now() + ")"
			rslt, e := base.DB().Exec(asql, categoryid, code)
			if e == nil {
				cii, e = rslt.LastInsertId()
				if e == nil {
					asql = "insert into category_description(category_item_id,language_id,category_id,item_name,item_description)"
					asql += " values(?,?,?,?,?)"
					_, e = base.DB().Exec(asql, cii, languageid, categoryid, name, description)
					if e != nil {
						errorLog.Println(asql, cii, languageid, categoryid, name, description, e.Error())
					}
				}
			} else {
				errorLog.Println(asql, categoryid, code, e.Error())
			}
		}
		if cii > 0 {
			keywords := strings.Join(base.WordSlice(code+" "+strings.ToLower(name)), " ")
			asql = "update category_item set keywords=? where category_item_id=?"
			_, e := base.DB().Exec(asql, keywords, cii)
			if e != nil {
				errorLog.Println(asql, keywords, cii, e.Error())
			}
		}
	}
}

type languageT struct {
	Selected   bool
	ID         int
	Code, Name string
}

func getLanguageSelection(selectedID int) (languages []languageT) {
	if base.DB() != nil {
		asql := "select language_id,code,name from language order by frequency"
		rows, e := base.DB().Query(asql)
		if e == nil {
			for rows.Next() {
				var id int
				var code, name sql.NullString
				e = rows.Scan(&id, &code, &name)
				if e == nil {
					languages = append(languages, languageT{selectedID == id, id, code.String, name.String})
				}
			}
			rows.Close()
		}
	}
	return
}

//pad_formats: 0000,00
func trimPAD(code, pad_formats string) (tcode string) {
	tcode = code
	if len(pad_formats) > 0 {
		ff := strings.Split(pad_formats, ",")
		for _, f := range ff {
			tcode = strings.TrimSuffix(tcode, f)
		}
	}
	return
}

func updateParent(categoryid, pad_formats string) (maxpathlen int) {
	maxpathlen = 0
	if base.DB() != nil {
		codes := []string{}
		codeItem := make(map[string]int)
		asql := "select category_item_id,identifier from category_item where category_id=?"
		rows, e := base.DB().Query(asql, categoryid)
		if e == nil {
			for rows.Next() {
				var data_value sql.NullString
				var item_id int
				e = rows.Scan(&item_id, &data_value)
				if e == nil {
					code := data_value.String
					if len(code) > 0 {
						codeItem[code] = item_id
						codes = append(codes, code)
					}
				}
			}
			rows.Close()
		}
		sort.Strings(codes)
		n := len(codes)
		codepaths := []string{}
		for i, code := range codes {
			item_id, _ := codeItem[code]
			parent_code := ""
			var parent_item_id int = 0
			ipos, is_leaf := 0, 1
			for k := i - 1; k >= 0; k-- {
				if strings.HasPrefix(code, trimPAD(codes[k], pad_formats)) {
					parent_code = codes[k]
					ipos = k + 1
					break
				}
			}
			if len(parent_code) > 0 {
				parent_item_id, _ = codeItem[parent_code]
				codepaths = append(codepaths, codepaths[ipos-1]+"."+code)
			} else {
				codepaths = append(codepaths, code)
			}
			for k := i + 1; k < n; k++ {
				if strings.HasPrefix(codes[k], trimPAD(code, pad_formats)) {
					is_leaf = 0
					break
				}
			}
			m := len(codepaths[i])
			if m > maxpathlen {
				maxpathlen = m
			}
			asql = "update category_item set category_item_parentid=?,is_leaf=?,item_hierarchy=?,depth=? where category_item_id=?"
			_, e := base.DB().Exec(asql, parent_item_id, is_leaf, codepaths[i], strings.Count(codepaths[i], ".")+1, item_id)
			if e != nil {
				errorLog.Println(asql, parent_item_id, is_leaf, codepaths[i], item_id, e.Error())
			}
		}
	}
	return
}

/*
create table category_item(
	category_item_id int NOT NULL auto_increment,
	category_id int default '0',
	identifier varchar(24),
	category_item_parentid int default '0',
	item_hierarchy varchar(96),
	showorder tinyint default 0,
	time_added datetime default 0,
	last_modified datetime default 0,
	status tinyint default 1,
	primary key(category_item_id)
)
*/

func CategoryitemHandler(w http.ResponseWriter, r *http.Request) {
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		db := base.DB()
		if db != nil {
			r.ParseForm()
			var selectedLanguageID int = 0
			categoryid := strings.Trim(r.FormValue("id"), BLANK_CUTSET)
			if r.Method == "POST" {
				needUpdateParent := false
				categoryid = r.FormValue("categoryid")
				languageid := r.FormValue("language")
				padformats := r.FormValue("pad_formats")
				if len(r.FormValue("remove")) > 0 {
					accessLog.Println("===remove category data:")
					for _, v := range r.Form["chooser"] {
						asql := "delete from category_item where category_item_id=?"
						db.Exec(asql, v)
						accessLog.Println(asql, v)
						asql = "delete from category_description where category_item_id=?"
						db.Exec(asql, v)
						accessLog.Println(asql, v)
						needUpdateParent = true
					}
				} else if len(r.FormValue("import")) > 0 {
					items := r.FormValue("items")
					lines := strings.Split(items, "\r\n")
					if len(lines) > 0 {
						seperator := r.FormValue("seperator")
						sp := "\t"
						if seperator == "space" {
							sp = " "
						} else if seperator == "comma" {
							sp = ","
						} else if seperator == "dot" {
							sp = "."
						} else if seperator == "semicolon" {
							sp = ";"
						} else if seperator == "asterisk" {
							sp = "*"
						}
						for _, ln := range lines {
							if len(strings.Trim(ln, BLANK_CUTSET)) > 0 { //skip empty line
								vv := strings.Split(ln, sp)
								n := len(vv)
								var code, name, description string
								if n > 0 {
									code = strings.Trim(vv[0], BLANK_CUTSET)
								}
								if n > 1 {
									name = strings.Trim(vv[1], BLANK_CUTSET)
								}
								if n > 2 {
									description = strings.Trim(vv[2], BLANK_CUTSET)
								}
								if len(code) > 0 {
									saveItem(categoryid, languageid, code, name, description)
									needUpdateParent = true
								}
							}
						}
					}
				}
				if needUpdateParent {
					updateParent(categoryid, padformats)
					languages := ""
					asql := "select group_concat(distinct language_id) from category_description where category_id=?"
					row := db.QueryRow(asql, categoryid) //待升级group_concat以适应多数据库
					if row != nil {
						var ss sql.NullString
						if row.Scan(&ss) == nil {
							languages = ss.String
							if len(languages) > 0 {
								languages = "#" + strings.Replace(languages, ",", "#", -1) + "#"
							}
						}
					}
					asql = "update category set languages=?,item_count=(select count(*) from category_item where category_id=?) where category_id=?"
					_, e := db.Exec(asql, languages, categoryid, categoryid)
					if e != nil {
						errorLog.Println(asql, categoryid, e.Error())
					}
				}
			}

			if base.IsDigital(categoryid) {
				asql := "select name,pad_formats," + base.SQL_dateformatYmd("time_added") + ",status from category where category_id=?"
				row := db.QueryRow(asql, categoryid)
				if row != nil {
					var name, pf sql.NullString
					var timeadded, status string
					e := row.Scan(&name, &pf, &timeadded, &status)
					if e == nil {
						locals["categoryid"] = categoryid
						locals["categoryname"] = name.String
						locals["pad_formats"] = pf.String
						locals["timeadded"] = timeadded
						locals["status"] = status
					}
				}
				if selectedLanguageID == 0 {
					asql = "select language_id,count(*) as n from category_description where category_id=? group by language_id order by n desc limit 1"
					row = db.QueryRow(asql, categoryid)
					if row != nil {
						n := 0
						e := row.Scan(&selectedLanguageID, &n)
						if e != nil && !strings.Contains(e.Error(), NO_ROWS) {
							errorLog.Println(asql, categoryid, e.Error())
						}
					}
				}
				if selectedLanguageID == 0 {
					selectedLanguageID = 1 //en
				}
				locals["languages"] = getLanguageSelection(selectedLanguageID)
				type categoryitemT struct {
					Category_item_id        string
					Code, Name, Description string
				}
				items := []categoryitemT{}
				asql = "select ci.category_item_id,ci.identifier,GROUP_CONCAT(cd.item_name),GROUP_CONCAT(cd.item_description) from category_item ci"
				asql += " left join category_description cd on ci.category_item_id=cd.category_item_id where ci.category_id=? group by ci.category_item_id"
				rows, e := db.Query(asql, categoryid) //待升级group_concat以适应多数据库
				if e == nil {
					for rows.Next() {
						var id string
						var code, name, desc sql.NullString
						e = rows.Scan(&id, &code, &name, &desc)
						if e == nil {
							items = append(items, categoryitemT{id, code.String, name.String, desc.String})
						}
					}
					rows.Close()
				}
				locals["items"] = items
				locals["itemcount"] = len(items)
			}
		}
		web.AdminHtml(w, r, "categoryitem", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func LexiconHandler(w http.ResponseWriter, r *http.Request) {
	db := base.DB()
	if db == nil {
		http.Redirect(w, r, "/nodatabase", http.StatusFound)
		return
	}
	selectedLanguageID := 0
	language := base.PreferredLanguage(r.Header["Accept-Language"])
	if len(language) > 0 {
		selectedLanguageID = base.Str2int(base.Language_id(language))
	}
	signed, user, user_type := base.ReadManagerLogin(r, cookieStore)
	base.VisitLog(visitLog, r, 0)
	if signed && user_type == 100 {
		r.ParseForm()
		categoryid := strings.Trim(r.FormValue("id"), BLANK_CUTSET)
		locals := make(map[string]interface{})
		locals["signed"] = signed
		locals["username"] = user
		locals["usertype"] = user_type
		if base.IsDigital(categoryid) {
			if selectedLanguageID == 0 {
				asql := "select language_id,count(*) as n from category_description where category_id=? group by language_id order by n desc limit 1"
				row := db.QueryRow(asql, categoryid)
				if row != nil {
					n := 0
					e := row.Scan(&selectedLanguageID, &n)
					if e != nil && !strings.Contains(e.Error(), NO_ROWS) {
						errorLog.Println(asql, categoryid, e.Error())
					}
				}
			}
			if selectedLanguageID == 0 {
				selectedLanguageID = 2 //cn
			}
			if r.Method == "POST" {
				type codeT struct {
					codes []string
				}
				mapCode := make(map[string]codeT)
				asql := "delete from category_word_code where category_id=?"
				db.Exec(asql, categoryid)
				asql = "delete from category_namechar where category_id=?"
				db.Exec(asql, categoryid)
				type itemT struct {
					Parentid   int
					Code, Name string
				}
				mapItem := make(map[int]itemT)
				asql = "select ci.category_item_id,ci.category_item_parentid,ci.identifier,cd.item_name from category_item ci"
				asql += " left join category_description cd on ci.category_item_id=cd.category_item_id and cd.language_id=?"
				asql += " where ci.category_id=?"
				rows, e := db.Query(asql, selectedLanguageID, categoryid)
				accessLog.Println(asql, selectedLanguageID, categoryid)
				if e == nil {
					for rows.Next() {
						var cii, cip int
						var code, name sql.NullString
						e = rows.Scan(&cii, &cip, &code, &name)
						if e == nil {
							mapItem[cii] = itemT{cip, code.String, name.String}
						} else {
							errorLog.Println(asql, "scan", e.Error())
						}
					}
					rows.Close()
				}
				/*create table category_namechar(
					category_item_id int default 0,
					category_id int default 0,
					name_char varchar(96) DEFAULT '',
					name_path varchar(255) DEFAULT '',
					primary key(category_item_id)
				)
								create table category_word_code(
									category_id int DEFAULT 0,
									word varchar(36) DEFAULT '',
									codes text,
									primary key(category_id,word)
								)*/
				for id, v := range mapItem {
					name_char := district.ExtractCharacter(v.Name)
					var ok bool
					name_path := ""
					vv := v
					for {
						name_path = vv.Name + name_path
						if vv.Parentid == 0 {
							break
						} else {
							vv, ok = mapItem[vv.Parentid]
							if !ok {
								break
							}
						}
					}
					asql = "insert into category_namechar(category_item_id,category_id,name_char,name_path) values(?,?,?,?)"
					_, e := db.Exec(asql, id, categoryid, name_char, name_path)
					if e != nil {
						errorLog.Println(asql, id, categoryid, name_char, name_path, e.Error())
					}
					ncnc := base.FullWordSlice(name_char)
					for _, nc := range ncnc {
						wc, ok := mapCode[nc]
						if ok {
							exists, _ := base.In_array(nc, wc.codes)
							if !exists {
								wc.codes = append(wc.codes, v.Code)
								mapCode[nc] = wc
							}
						} else {
							var wc codeT
							wc.codes = append(wc.codes, v.Code)
							mapCode[nc] = wc
						}
					}
				}
				for k, v := range mapCode {
					asql := "insert into category_word_code(category_id,word,codes) values(?,?,?)"
					_, e := db.Exec(asql, categoryid, k, strings.Join(v.codes, ","))
					if e != nil {
						errorLog.Println(asql, categoryid, k, v.codes)
					}
				}
			}

			locals["categoryid"] = categoryid
			type wordcodeT struct {
				Word  string
				Codes string
			}
			wordcodes := []wordcodeT{}
			asql := "select word,codes from category_word_code where category_id=?"
			rows, e := db.Query(asql, categoryid)
			if e == nil {
				for rows.Next() {
					var word, codes sql.NullString
					e = rows.Scan(&word, &codes)
					if e == nil {
						wordcodes = append(wordcodes, wordcodeT{word.String, codes.String})
					}
				}
				rows.Close()
			}
			accessLog.Println(wordcodes)
			locals["wordcodes"] = wordcodes
		}
		web.AdminHtml(w, r, "lexicon", locals)
	} else {
		http.Redirect(w, r, "/login", http.StatusFound)
	}
}

func Json_districtHandler(w http.ResponseWriter, r *http.Request) {
	accessLog.Println("Json_districtHandler===")
	base.VisitLog(visitLog, r, 0)
	w.Header().Set("Content-Type", "application/json;charset=utf-8")
	type responseT struct {
		Code, Msg string
		District  map[string]string
	}
	var res responseT
	res.Code = "200"
	res.Msg = "error"
	res.District = make(map[string]string)
	category_id := 0
	db := base.DB()
	asql := "select category_id from category where name='行政区划'"
	row := db.QueryRow(asql)
	if row != nil {
		e := row.Scan(&category_id)
		if e != nil {
			errorLog.Println(asql, e.Error())
		}
	}
	if category_id > 0 {
		asql := "select ci.identifier,cnc.name_path from category_item ci"
		asql += " left join category_namechar cnc on ci.category_item_id=cnc.category_item_id"
		asql += " where ci.category_id=?"
		rows, e := db.Query(asql, category_id)
		if e == nil {
			for rows.Next() {
				var code, name_path sql.NullString
				e = rows.Scan(&code, &name_path)
				if e == nil {
					res.District[code.String] = name_path.String
				}
			}
			rows.Close()

			res.Code = "100"
			res.Msg = ""
		} else {
			errorLog.Println(asql, category_id, e.Error())
		}
	}

	data, _ := json.Marshal(res)
	w.Write(data)
}

func Json_wordcodeHandler(w http.ResponseWriter, r *http.Request) {
	accessLog.Println("Json_wordcodeHandler===")
	base.VisitLog(visitLog, r, 0)
	w.Header().Set("Content-Type", "application/json;charset=utf-8")
	type responseT struct {
		Code, Msg string
		Wordcode  map[string]string
	}
	var res responseT
	res.Code = "200"
	res.Msg = "error"
	res.Wordcode = make(map[string]string)
	category_id := 0
	db := base.DB()
	asql := "select category_id from category where name='行政区划'"
	row := db.QueryRow(asql)
	if row != nil {
		e := row.Scan(&category_id)
		if e != nil {
			errorLog.Println(asql, e.Error())
		}
	}
	if category_id > 0 {
		asql := "select word,codes from category_word_code where category_id=?"
		rows, e := db.Query(asql, category_id)
		if e == nil {
			for rows.Next() {
				var word, codes sql.NullString
				e = rows.Scan(&word, &codes)
				if e == nil {
					res.Wordcode[word.String] = codes.String
				}
			}
			rows.Close()

			res.Code = "100"
			res.Msg = ""
		} else {
			errorLog.Println(asql, category_id, e.Error())
		}
	}

	data, _ := json.Marshal(res)
	w.Write(data)
}

func getCategoryID(category_name string) (category_id int) {
	category_id = 0
	db := base.DB()
	asql := "select category_id from category where name=?"
	row := db.QueryRow(asql, category_name)
	if row != nil {
		e := row.Scan(&category_id)
		if e != nil {
			errorLog.Println(asql, e.Error())
		}
	}
	return
}

type categoryT struct {
	Item_id   string
	Item_code string
	Item_name string
	Is_leaf   bool
	Scale     string
}
type firstgradeT struct {
	Item_id   string
	Item_code string
	Item_name string
	Is_leaf   bool
	Scale     string
	Children  []categoryT
}

func GetCategoryItems(category_id, item_parentid int, language_id string) (items []firstgradeT) {
	if category_id > 0 {
		db := base.DB()
		var is_leaf int
		var scale string
		var item_id, item_code, item_name sql.NullString
		asql := "select ci.category_item_id,ci.identifier,cd.item_name,ci.is_leaf,ci.scale from category_item ci"
		asql += " left join category_description cd on ci.category_item_id=cd.category_item_id and cd.language_id=?"
		asql += " where ci.category_id=? and ci.category_item_parentid=?"
		asql += " order by ci.scale desc,ci.identifier"
		rows, e := db.Query(asql, language_id, category_id, item_parentid)
		if e == nil {
			for rows.Next() {
				e = rows.Scan(&item_id, &item_code, &item_name, &is_leaf, &scale)
				if e == nil {
					var fg firstgradeT
					fg.Item_id = item_id.String
					fg.Item_code = item_code.String
					fg.Item_name = item_name.String
					fg.Is_leaf = (is_leaf == 1)
					fg.Scale = scale
					items = append(items, fg)
				}
			}
			rows.Close()
		}
		n := len(items)
		for i := 0; i < n; i++ {
			rows, e = db.Query(asql, language_id, category_id, items[i].Item_id)
			if e == nil {
				for rows.Next() {
					e = rows.Scan(&item_id, &item_code, &item_name, &is_leaf, &scale)
					if e == nil {
						items[i].Children = append(items[i].Children, categoryT{item_id.String, item_code.String, item_name.String, (is_leaf == 1), scale})
					}
				}
				rows.Close()
			}
		}
	}
	return
}

func entranceBlock(items []firstgradeT) (block string) {
	return
}

func breadCrumbs(category_item_id int, language_id string) (block string) {
	var item_hierarchy string
	var n = 0
	db := base.DB()
	asql := "select item_hierarchy from category_item where category_item_id=?"
	row := db.QueryRow(asql, category_item_id)
	if row != nil {
		var ns sql.NullString
		e := row.Scan(&ns)
		if e == nil {
			item_hierarchy = strings.Replace(ns.String, ".", ",", -1)
			n = strings.Count(item_hierarchy, ",")
		}
	}
	asql = "select ci.category_item_id,cd.item_name from category_item ci"
	asql += " left join category_description cd on ci.category_item_id=cd.category_item_id and cd.language_id=?"
	asql += " where ci.category_item_id in (" + item_hierarchy + ") order by ci.category_item_id"
	rows, e := db.Query(asql, language_id)
	if e == nil {
		var i = 0
		for rows.Next() {
			if i > 0 {
				block += "&nbsp;&gt;&nbsp;"
			}
			var item_id string
			var item_name sql.NullString
			e = rows.Scan(&item_id, &item_name)
			if e == nil {
				if i == n {
					block += "<span class=\"focusitem\">" + item_name.String + "</span>"
				} else {
					block += "<a href=\"/categorylist?id=" + item_id + "\" class=\"parentitem\">" + item_name.String + "</a>"
				}
			}
			i++
		}
		rows.Close()
	} else {
		errorLog.Println(asql, e.Error())
	}
	return
}
